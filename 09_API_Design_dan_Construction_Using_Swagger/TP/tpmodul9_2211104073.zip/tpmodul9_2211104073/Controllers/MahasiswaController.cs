﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using tpmodul9_2211104073.Models;

namespace tpmodul9_2211104073.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MahasiswaController : ControllerBase
    {
        // Daftar mahasiswa statis
        private static List<Mahasiswa> mahasiswaList = new List<Mahasiswa>
        {
            new Mahasiswa("Naufal Aflakh Wijayanto", "2211104073"),
            new Mahasiswa("Muhammad Fariz Nur Hidayat", "2211104069"),
            new Mahasiswa("Putra Pratama Okta Riano", "2211104068"),
            new Mahasiswa("Allaya Daffa Zhilal", "2211104090")
        };

        // Endpoint GET untuk mengambil daftar mahasiswa
        [HttpGet]
        public ActionResult<IEnumerable<Mahasiswa>> GetMahasiswa()
        {
            return Ok(mahasiswaList);
        }

        // Endpoint GET untuk mengambil mahasiswa berdasarkan index
        [HttpGet("{index}")]
        public ActionResult<Mahasiswa> GetMahasiswaByIndex(int index)
        {
            if (index < 0 || index >= mahasiswaList.Count)
            {
                return NotFound(); // Mengembalikan 404 jika index tidak ditemukan
            }

            return Ok(mahasiswaList[index]);
        }

        // Endpoint POST untuk menambahkan mahasiswa baru
        [HttpPost]
        public ActionResult AddMahasiswa([FromBody] Mahasiswa mahasiswa)
        {
            mahasiswaList.Add(mahasiswa);
            return CreatedAtAction(nameof(GetMahasiswa), new { index = mahasiswaList.Count - 1 }, mahasiswa);
        }

        // Endpoint DELETE untuk menghapus mahasiswa berdasarkan index
        [HttpDelete("{index}")]
        public ActionResult DeleteMahasiswa(int index)
        {
            if (index < 0 || index >= mahasiswaList.Count)
            {
                return NotFound(); // Mengembalikan 404 jika index tidak ditemukan
            }

            mahasiswaList.RemoveAt(index);
            return NoContent(); // Mengembalikan status 204 jika penghapusan berhasil
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using modul9_2211104073.Models;  // Referensikan kelas Movie yang telah dibuat
using System.Collections.Generic;

namespace modul9_2211104073.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : ControllerBase
    {
        // Static list of Movies (menyimpan data film sementara di memori)
        private static List<Movie> movies = new List<Movie>
        {
            new Movie { Title = "Inception", Director = "Christopher Nolan", Stars = new List<string> { "Leonardo DiCaprio", "Joseph Gordon-Levitt" }, Description = "A thief who steals corporate secrets..." },
            new Movie { Title = "The Dark Knight", Director = "Christopher Nolan", Stars = new List<string> { "Christian Bale", "Heath Ledger" }, Description = "When the menace known as the Joker emerges..." },
            new Movie { Title = "The Matrix", Director = "Lana Wachowski, Lilly Wachowski", Stars = new List<string> { "Keanu Reeves", "Laurence Fishburne" }, Description = "A computer hacker learns from mysterious rebels..." }
        };

        // GET: api/Movies (mengambil semua film)
        [HttpGet]
        public ActionResult<IEnumerable<Movie>> Get()
        {
            return Ok(movies);
        }

        // GET: api/Movies/5 (mengambil film berdasarkan id/index)
        [HttpGet("{id}")]
        public ActionResult<Movie> Get(int id)
        {
            if (id < 0 || id >= movies.Count)
            {
                return NotFound();  // Mengembalikan 404 jika id tidak ditemukan
            }
            return Ok(movies[id]);  // Mengembalikan film dengan index/id yang sesuai
        }

        // POST: api/Movies (menambahkan film baru)
        [HttpPost]
        public ActionResult<Movie> Post([FromBody] Movie movie)
        {
            movies.Add(movie);  // Menambahkan film baru ke dalam list
            return CreatedAtAction(nameof(Get), new { id = movies.Count - 1 }, movie);  // Mengembalikan status "Created"
        }

        // DELETE: api/Movies/5 (menghapus film berdasarkan id/index)
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            if (id < 0 || id >= movies.Count)
            {
                return NotFound();  // Mengembalikan 404 jika id tidak ditemukan
            }
            movies.RemoveAt(id);  // Menghapus film berdasarkan id/index
            return NoContent();  // Mengembalikan status "NoContent" (204 OK)
        }
    }
}
